
package formulairefull;
public class Produit {
   
	private int matricule;
	private String nom;
	private float prix;
	private int annee_Fabrication;
	private String designation;
	public Produit (int matricule,String nom,float prix,int annee,String designation)
	{
	 this.nom=nom;
	 this.prix=prix;
	 this.annee_Fabrication=annee;
	 this.matricule=matricule;
	 this.designation=designation; 
	}
	void setMatricule(int matricule)
	{
	  this.matricule=matricule;
	}
	int getMatricule()
	{
	 return(this.matricule);
	}
	void setPrix(Float Prix)
	{
	  this.prix=Prix;
	}
	float getPrix()
	{
	 return(this.prix);
	}
	void setNom(String nom)
	{
	  this.nom=nom;
	}
	String getNom()
	{
	 return(this.nom);
	}
	void setDesignation(String des)
	{
	  this.designation=des;
	}
	String getDesignation()
	{
	 return(this.designation);
	}
	void setAnne(int annee)
	{
	  this.annee_Fabrication=annee;
	}
	int getAnnee()
	{
	 return(this.annee_Fabrication);
	}
}

    

